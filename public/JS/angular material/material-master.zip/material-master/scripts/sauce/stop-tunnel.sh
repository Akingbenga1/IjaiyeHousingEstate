#!/bin/bash

# Closes all instances of any Sauce Connector and waits for them to finish.
killall --wait sc